function OUT=nthout(N,FCN,varargin)
% OUT=NTHOUT(N,FCN,...)
% Returns the Nth output variable from the function FCN. This is used to
% efficiently clear unwanted variables from memory and the workspace.
%
% Taken from gnovice on stackoverflow:
% <http://stackoverflow.com/questions/3710466/how-do-i-get-the-second-return-value-from-a-function-without-using-temporary-var>

[OUT{1:N}] = FCN(varargin{:});
OUT = OUT{N};
end
