function [CLU,J]=clustlayer2(C,NE)
% [CLU,NUMC]=CLUSTLAYER2(C,NE) groups all of the observations in C into
% clusters based on the neighbors identified in NE. Note that diagonal
% neighbors (observations that are neighbors along all dimensions but do
% not share the same value in any dimension) are not considered neighbors.
%   C is an M-by-N vector whose rows contain M observations and whose
%       columns contain the indices of the observation along N dimensions.
%   NE is a cell array of logical square matrices where a true value at
%       NE{i}(j,k) indicates that the indices j and k in the ith column of
%       C are neighbors. All diagonal elements of NE must be true.
%   CLU is an M-by-N+1 vector containing the values in C sorted by cluster,
%       where the N+1th column of CLU contains the cluster number for each
%       observation.
%   NUMC is the number of clusters identified by CLUSTLAYER2.
%
%   See also: PERMTESTND, FIND_NEIGHBOR, CLUSTERT, ISMEMBER, INTERSECT, SETDIFF

% zfj, 04/08/15

CLU=[];
J=0;
while ~isempty(C) % iterate until all points are assigned to clusters
    J=J+1; % increment cluster number by 1
    lastt=find(ismember(C(:,1),find(NE{1}(C(1,1),:)))); % find neighbors in 1st dimension to first point among pool
    for i=2:size(C,2)
        lastt=intersect(lastt,find(ismember(C(:,i),find(NE{i}(C(1,i),:))))); % find neighbors in ith dimension to first point among pool and collect if neighbors in all dimensions
    end
    if size(C,2)>1
        ign=find(~any(ismember(C(lastt,:),C(1,:)),2)); % label points for deletion which do not share an index with the first cluster along any dimension
    else
        ign=[];
    end
    lastt(ismember(lastt,ign))=[]; % remove all ignored points from cluster
    prevt=1;
    while numel(lastt)~=numel(prevt) % compare previous points to current points
        prevt=lastt; % store current points as previous points
        lastt=find(ismember(C(:,1),find(any(NE{1}(C(prevt,1),:),1)))); % find neighbors in 1st dimension to previous point among pool
        for i=2:size(C,2)
            lastt=intersect(lastt,find(ismember(C(:,i),find(any(NE{i}(C(prevt,i),:),1))))); % find neighbors in ith dimension to previous points among pool and collect all points which are neighbors to previous points in all dimensions
        end
        if size(C,2)>1
            checkt=setdiff(lastt(~ismember(lastt,ign)),prevt); % collect all newly added points that haven't been labelled for ignore
            for k=1:numel(checkt)
                poss=find(any(ismember(C(prevt,:),C(checkt(k),:)),2)); % find old points that have the same index as the new point along any dimension (required to be neighbor)
                mem=[];
                if ~isempty(poss) % if there are possible neighbors...
                    for i=1:size(C,2)
                        mem=cat(2,mem,ismember(C(prevt(poss),i),find(NE{i}(C(checkt(k),i),:)))); % find possible neighbors that are neighbors along each dimension
                    end
                end
                if ~any(sum(mem,2)==size(C,2)) % if point is not a neighbor to any previous point along every dimension and does not have at least one index along any dimension in common...
                    ign=cat(1,ign,checkt(k)); % label point for ignore
                end
            end
            lastt(ismember(lastt,ign))=[]; % remove all ignored points from the cluster
        end
    end % if there were new points added, go back to check for neighbors of those points among pool
    CLU=cat(1,CLU,[C(prevt,:) J*ones(numel(prevt),1)]); % put points in new cluster
    C(prevt,:)=[]; % remove points from pool
end
end