function NE = find_neighbor(D,DT)
% NE=FIND_NEIGHBOR(D,DT) determines the points in D that are neighbors.
%   D is a cell array of Ni-by-Mi matrices, where Ni is the number of
%       points in the ith dimension of a dataset and Mi is the number of
%       dimensions that define the relationship between points. Each row j
%       in D{i} corresponds to the coordinates of the jth point in the
%       subspace of that dimension.
%   DT is a vector of distances beyond which the points in D are not
%       considered neighbors. Each DT(i) corresponds to the threshold
%       distance for D{i}.
%   NE is a cell array of logical square matrices where a true value at
%       NE{i}(j,k) indicates that the points j and k in D{i} are neighbors.
%       Diagonal elements of NE are always true.
%
%   Example:
%       If the dataset of interest is a 2-by-3 matrix of observations where
%       the rows represent different recording channels whose locations in
%       3-dimensional space are known, and the columns represent
%       sequential, evenly sampled timepoints, then D and DT might be
%       defined as:
%           D{1} = [ X_1,Y_1,Z_1 ; X_2,Y_2,Z_2]
%               % where channel 1 is recorded from position (X_1,Y_1,Z_1),
%               % and channel 2 is recorded from position (X_2,Y_2,Z_2).
%           D{2} = [ 1:3' zeros(3,1)]
%               % NB: timepoints can be thought of as coordinates along a
%               % t-axis, i.e., (0,1), (0,2), (0,3)
%           DT =  [4, 1]
%               % where the units of DT correspond to the units of D:
%               % if X_1,Y_1,Z_1,X_2,Y_2,Z_2 are in centimeters, then
%               %    neighbors are no more than 4 cm apart
%               % timepoints must be sequential to be neighbors
%               %    NB: setting a higher threshold will allow timepoints
%               %        to be skipped and still be neighbors
%
%       The output from FIND_NEIGHBOR(D,DT) will be:
%           NE =
%
%               [2x2 double]    [3x3 double]
%
%       NE{1} will be a ones matrix if channel 1 and channel 2 are neighbors
%       and a diagonal matrix of ones if they are not. NE{2} will be a
%       matrix with diagonal ones, superdiagonal ones, and subdiagonal
%       ones:
%                   +-    -+      +-    -+             +-     -+
%                   | 1  1 |      | 1  0 |             | 1 1 0 |
%           NE{1} = |      |  or  |      |     NE{2} = | 1 1 1 |
%                   | 1  1 |      | 0  1 |             | 0 1 1 |
%                   +-    -+      +-    -+             +-     -+
%
%   See also: PERMTESTND, PDIST, CLUSTERT, CLUSTLAYER2

% zfj, 04/08/15

NE = cell(size(D));
for i=1:numel(D)
    NE{i}=squareform(pdist(D{i}))<=DT(i);
end

end